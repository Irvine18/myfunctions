# myfunctions
This is a library which consists of recursive functions and sorting functions.

## building this package locally
`python setup.py sdist`

## installing this package from Github
`pip install git+https://github.com/Irvine18/myfunctions.git`

## updating this package from Github
`pip install --upgrade git+https://github.com/Irvine18/myfunctions.git`
